#!/usr/bin/env python3
"""UI smoke checks for the preschool learning app on a real Android AVD."""
import subprocess, time, re, sys
PKG='com.zapia.aylanis'

def sh(*args, check=True):
    return subprocess.run(args, check=check, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT).stdout

def dump():
    sh('adb','shell','uiautomator','dump','/sdcard/window.xml',check=False)
    return sh('adb','shell','cat','/sdcard/window.xml',check=False)

def nodes():
    xml=dump()
    return [(re.sub(r'&amp;','&',t), b) for t,b in re.findall(r'<node[^>]*text="([^"]*)"[^>]*bounds="(\[[^\"]+\])"',xml)]

def tap_text(text, timeout=15, exact=False):
    end=time.time()+timeout
    while time.time()<end:
        for got,bounds in nodes():
            if (got==text if exact else text in got):
                m=re.match(r'\[(\d+),(\d+)\]\[(\d+),(\d+)\]',bounds)
                if m:
                    x1,y1,x2,y2=map(int,m.groups())
                    sh('adb','shell','input','tap',str((x1+x2)//2),str((y1+y2)//2))
                    time.sleep(.8);return got
        sh('adb','shell','input','swipe','350','350','350','100','250')
        time.sleep(.4)
    raise AssertionError(f'No se encontró el texto tocable: {text!r}; UI={nodes()}')

def back():
    sh('adb','shell','input','keyevent','4');time.sleep(1)

def assert_no_crash(stage):
    logs=sh('adb','logcat','-d','-t','600',check=False)
    if 'FATAL EXCEPTION' in logs or 'Process: '+PKG+', PID:' in logs:
        raise AssertionError(f'Cierre inesperado en {stage}:\n'+logs[-7000:])
    if sh('adb','shell','pidof',PKG,check=False).strip()=='' :
        raise AssertionError(f'La app no está abierta después de {stage}')

def text_values(): return [x for x,_ in nodes()]

def has_text(fragment): return any(fragment in x for x in text_values())

# Install and start a clean first-run flow.
sh('adb','shell','pm','clear',PKG,check=False)
sh('adb','install','-r','project/app/build/outputs/apk/debug/app-debug.apk')
sh('adb','shell','am','force-stop',PKG)
sh('adb','shell','am','start','-n',PKG+'/.MainActivity')
time.sleep(2)
assert_no_crash('inicio/configuración')
tap_text('Comenzar')
time.sleep(7)
assert_no_crash('intro Smart Technology y menú')
# Enter the vowels section and verify the learn and challenge games launch.
tap_text('Vocales');time.sleep(1)
tap_text('Aprende las vocales');time.sleep(1)
assert_no_crash('lección de vocales')
back();time.sleep(1)
tap_text('Organiza las vocales');time.sleep(1)
assert_no_crash('reto de vocales')
# An incorrect random button must not give points; correct answers advance five rounds.
tap_text('E',exact=True);time.sleep(.6)
assert has_text('⭐ 0'), 'Una respuesta incorrecta/no terminada alteró los puntos.'
for vowel in ['A','E','I','O','U']:
    tap_text(vowel,exact=True);time.sleep(.7)
assert has_text('⭐ 10'), 'Completar cinco respuestas correctas no entregó la recompensa esperada.'
assert_no_crash('cinco retos de vocales y puntos')
# Adivina palabras must present a picture and empty slots, never the answer already spelled.
back();time.sleep(1)
back();time.sleep(1)
tap_text('Letras');time.sleep(1)
tap_text('Adivina palabras');time.sleep(1)
vals=text_values()
assert any('☀' in x for x in vals), f'No aparece la imagen del primer reto: {vals}'
assert not any(x.strip()=='SOL' for x in vals), f'La respuesta está revelada: {vals}'
for letter in ['S','O','L']: tap_text(letter,exact=True)
tap_text('Comprobar');time.sleep(.7)
assert_no_crash('formar y comprobar palabra')
print('EMULATOR_SMOKE_OK: install, first-run intro, lesson, wrong-answer zero points, five correct answers award 10, picture word guessing and app stays alive')
