package com.zapia.aylanis

import android.content.pm.ActivityInfo
import android.media.MediaPlayer
import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.geometry.Offset
import androidx.activity.compose.BackHandler
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.platform.LocalContext
import java.util.Locale
import kotlin.math.max

private val Night=Color(0xFF101A2A)
private val Panel=Color(0xFF1B2B42)
private val Panel2=Color(0xFF263B56)
private val Gold=Color(0xFFFFD166)
private val Aqua=Color(0xFF68DDE0)
private val White=Color(0xFFF7FAFF)
private val LessonVowels=listOf("A","E","I","O","U")
private val VowelHints=listOf("A de avión","E de estrella","I de iguana","O de oso","U de uvas")
private val ColorsLesson=listOf("Rojo","Azul","Amarillo","Verde","Naranja","Morado")
private val ColorHex=listOf(0xFFE64A4A,0xFF4096F4,0xFFFFCF45,0xFF42B66A,0xFFFF8A38,0xFFAA70DB)
private val Shapes=listOf("Círculo","Triángulo","Cuadrado","Rectángulo","Estrella","Rombo")
private data class ActivityItem(val title:String,val subtitle:String,val emoji:String,val category:String,val puzzle:Boolean=false)
private val Activities=listOf(
 ActivityItem("Organiza las vocales","Acomoda A, E, I, O, U para que pase el tren","🚂","Vocales",true),
 ActivityItem("Piano de vocales","Toca las vocales y crea una melodía","🎹","Vocales"),
 ActivityItem("Escucha la música","Escucha la música de la aventura","🎵","Música"),
 ActivityItem("Aprende las vocales","Escucha y descubre cada vocal","🔤","Vocales"),
 ActivityItem("Organiza los colores","Ordena del más claro al más oscuro","🖍️","Colores",true),
 ActivityItem("Teclado de colores","Combina colores para descubrir otros","🎨","Colores"),
 ActivityItem("Paleta de colores","Crea una ruleta y hazla girar","🌈","Colores"),
 ActivityItem("Aprende los colores","Mira, escucha y descubre","🪣","Colores"),
 ActivityItem("Colorea y dibuja","Dibuja con tus colores favoritos","🖌️","Colores"),
 ActivityItem("Organiza las letras","Ordena el abecedario para el tren","🚂","Letras",true),
 ActivityItem("Adivina palabras","Descubre la palabra secreta","🔎","Letras",true),
 ActivityItem("Haz la palabra correcta","Forma palabras con el teclado","⌨️","Letras",true),
 ActivityItem("Aprende las letras","Conoce el abecedario","📚","Letras"),
 ActivityItem("Teclado de letras","Escribe lo que quieras","🔠","Letras"),
 ActivityItem("Aprende los números","Descubre números y símbolos","🔢","Números"),
 ActivityItem("Resuelve operaciones","Sumas y restas para ganar puntos","➕","Números",true),
 ActivityItem("Teclado de números","Escribe números y símbolos","🔣","Números"),
 ActivityItem("Calculadora","Practica con una calculadora","🧮","Números"),
 ActivityItem("Aprende las formas","Descubre formas y figuras","🔺","Formas"),
 ActivityItem("Teclado de formas","Toca una forma para verla","🔷","Formas"),
 ActivityItem("Dibuja formas","Dibuja la figura que te pido","✏️","Formas",true),
 ActivityItem("Organiza formas","Ordénalas por sus puntas","📐","Formas",true)
)

class MainActivity:ComponentActivity(),TextToSpeech.OnInitListener {
 private var tts:TextToSpeech?=null; private var ttsReady=false; private var music:MediaPlayer?=null; private var intro:MediaPlayer?=null
 private val prefs by lazy { getSharedPreferences("aylanis_game",MODE_PRIVATE) }
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);tts=TextToSpeech(this,this)
  window.statusBarColor=android.graphics.Color.rgb(16,26,42);window.navigationBarColor=android.graphics.Color.rgb(16,26,42)
  requestedOrientation=if(prefs.getString("orientation","Horizontal")=="Vertical")ActivityInfo.SCREEN_ORIENTATION_PORTRAIT else ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
  val first=prefs.getBoolean("configured",false)
  setContent { App(startAtSetup=!first) }
 }
 @Composable private fun App(startAtSetup:Boolean){
  var configured by remember { mutableStateOf(!startAtSetup) }
  var name by remember { mutableStateOf(prefs.getString("child_name","Aylanis")?:"Aylanis") }
  var orientation by remember { mutableStateOf(prefs.getString("orientation","Horizontal")?:"Horizontal") }
  var musicEnabled by remember { mutableStateOf(prefs.getBoolean("music",true)) }
  var page by remember { mutableStateOf(if(configured)"splash" else "setup") }
  var category by remember { mutableStateOf("Inicio") }
  var currentActivity by remember { mutableStateOf<ActivityItem?>(null) }
  var points by remember { mutableIntStateOf(prefs.getInt("points",0)) }
  val previousOpen=prefs.getLong("last_open",System.currentTimeMillis())
  val awayDays=((System.currentTimeMillis()-previousOpen).coerceAtLeast(0L)/86_400_000L).toInt()
  var health by remember { mutableIntStateOf((prefs.getInt("health",100)-awayDays*15).coerceAtLeast(0)) }
  var lastOpen by remember { mutableLongStateOf(previousOpen) }
  var hintCount by remember { mutableIntStateOf(prefs.getInt("hint_count",0)) }
  var hintOn by remember { mutableStateOf(false) }
  var learnedIndex by remember { mutableIntStateOf(0) }
  var puzzleIndex by remember { mutableIntStateOf(0) }
  var input by remember { mutableStateOf("") }
  var message by remember { mutableStateOf("") }
  var selectedColor by remember { mutableIntStateOf(0) }
  var mixed by remember { mutableStateOf(listOf<Int>()) }
  var drawPoints by remember { mutableStateOf(listOf<Offset>()) }
  var showReset by remember { mutableStateOf(false) }
  val ctx= LocalContext.current
  val horizontal=orientation=="Horizontal"
  fun say(s:String){ speak(s) }
  fun changeOrientation(o:String){orientation=o;prefs.edit().putString("orientation",o).apply();requestedOrientation=if(o=="Horizontal")ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_PORTRAIT}
  fun setMusic(on:Boolean){musicEnabled=on;prefs.edit().putBoolean("music",on).apply();if(on) startMusic() else stopMusic()}
  fun goActivity(a:ActivityItem){currentActivity=a;page="game";input="";message="";hintOn=false;puzzleIndex=0;learnedIndex=0;drawPoints=emptyList();mixed=emptyList();say(when(a.title){"Aprende las vocales"->"Vamos a aprender las vocales, $name";"Aprende los colores"->"Vamos a aprender los colores, $name";else->"Comencemos con ${a.title}, $name"})}
  fun earn(n:Int=5){points+=n;prefs.edit().putInt("points",points).apply()}
  fun hint(){if(hintCount>0){hintCount--;prefs.edit().putInt("hint_count",hintCount).apply();hintOn=true;message="Pista: ${currentActivity?.let{when(it.category){"Vocales"->"Recuerda el orden A, E, I, O, U.";"Colores"->"Compara primero los colores más claros.";"Números"->"Cuenta con tus dedos y piensa en la operación.";"Formas"->"Mira cuántas puntas tiene cada figura.";else->"Busca la primera letra."}}?:"Mira con atención."}";say(message)}}
  MaterialTheme(colorScheme=darkColorScheme(primary=Gold,secondary=Aqua,background=Night,surface=Panel,onSurface=White)) {
   BackHandler(enabled=page!="home" && page!="setup"){page=when(page){"game"->"activities";"activities","settings","shop"->if(currentActivity!=null && page=="shop")"game" else "home";else->"home"}}
   BoxWithConstraints(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF13243A),Night)))) {
    val isWide=maxWidth>maxHeight
    when(page){
     "setup" -> SetupScreen(name,{name=it},{orientation=it;changeOrientation(it)},{setMusic(it);musicEnabled=it},{configured=true;requestedOrientation=if(orientation=="Horizontal")ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_PORTRAIT;prefs.edit().putBoolean("configured",true).putString("child_name",name).putString("orientation",orientation).putBoolean("music",musicEnabled).putInt("health",health).putLong("last_open",System.currentTimeMillis()).apply();page="splash"},musicEnabled)
     "splash" -> SplashScreen(name,onDone={page="home";lastOpen=System.currentTimeMillis();prefs.edit().putLong("last_open",lastOpen).apply();if(musicEnabled)startMusic();playIntro();say("Hola $name, te hemos extrañado mucho. Soy tu profesor. ¡Comencemos a jugar!")},onSetup={page="setup"})
     "home" -> HomeScreen(name,points,health,hintCount,horizontal,isWide,musicEnabled,onCategory={category=it;page=if(it=="Tienda")"shop" else if(it=="Configuración")"settings" else "activities";say(if(it=="Tienda")"Bienvenido a la tienda, $name" else "Elige una actividad")},onSettings={page="settings"},onShop={page="shop"})
     "activities" -> ActivityListScreen(category,if(category=="Juegos")Activities.filter{it.puzzle}else Activities.filter{it.category==category},name,points,health,horizontal,isWide,onBack={page="home"},onPick={goActivity(it)},onShop={page="shop"})
     "game" -> GameScreen(item=currentActivity!!,name=name,horizontal=horizontal,isWide=isWide,points=points,health=health,hintCount=hintCount,hintOn=hintOn,message=message,input=input,puzzleIndex=puzzleIndex,learnedIndex=learnedIndex,selectedColor=selectedColor,mixed=mixed,drawPoints=drawPoints,
       onBack={page="activities"},onHint={hint()},onInput={input=it},onSpeak={say(it)},onNext={puzzleIndex++;input="";hintOn=false;message="¡Muy bien! Ganaste 5 puntos.";earn();say(message)},onCheck={answer-> if(answer){message="¡Correcto, $name! Ganaste 5 puntos.";earn();say(message);puzzleIndex++;input="";hintOn=false}else{message="¡Sigue intentando! Tú puedes.";say(message)}},onLearnNext={learnedIndex++},onColor={selectedColor=it;mixed=mixed+it},onClearMix={if(mixed.isNotEmpty())mixed=mixed.dropLast(1)},onDraw={drawPoints=(drawPoints+it).toMutableList()},onClearDraw={drawPoints=emptyList()},onShop={page="shop"})
     "shop" -> ShopScreen(points,health,hintCount,onBack={page=if(currentActivity!=null)"game" else "home"},onBuyHint={if(points>=5){points-=5;hintCount++;prefs.edit().putInt("points",points).putInt("hint_count",hintCount).apply()}},onBuyMedicine={if(points>=20&&health<100){points-=20;health=(health+40).coerceAtMost(100);prefs.edit().putInt("points",points).putInt("health",health).apply()}else if(health>=100)message="¡Tu profesor está perfectamente!" else message="Te faltan puntos para la medicina."})
     else -> SettingsScreen(name,{name=it;prefs.edit().putString("child_name",it).apply()},orientation,{changeOrientation(it)},musicEnabled,{setMusic(it)},onBack={page="home"},onReset={showReset=true},onShop={page="shop"},onAddProfile={message="Puedes cambiar el nombre del perfil actual aquí. Próximamente: varios perfiles guardados."})
    }
    if(showReset) AlertDialog(onDismissRequest={showReset=false},title={Text("¿Reiniciar el progreso?")},text={Text("Volverás a cero puntos y tu profesor estará bien. Se conservarán el nombre, la orientación y la música.")},confirmButton={TextButton(onClick={points=0;health=100;prefs.edit().putInt("points",0).putInt("health",100).putLong("last_open",System.currentTimeMillis()).apply();showReset=false;page="home"}){Text("Reiniciar")}},dismissButton={TextButton(onClick={showReset=false}){Text("Cancelar")}})
   }
  }
 }
 @Composable private fun SetupScreen(name:String,onName:(String)->Unit,orient:(String)->Unit,musicSet:(Boolean)->Unit,onStart:()->Unit,music:Boolean){
  var localName by remember(name){mutableStateOf(name)}
  Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal=20.dp, vertical=12.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(10.dp)){
   Image(painterResource(R.drawable.logo_app),null,Modifier.size(95.dp).clip(RoundedCornerShape(24.dp)))
   Text("Vocales y letras aprende",fontSize=25.sp,fontWeight=FontWeight.Black,color=Gold,textAlign=TextAlign.Center)
   Text("Configuración para tía Belkis",fontSize=19.sp,fontWeight=FontWeight.Bold)
   Text("Por favor, configura la aplicación para ${localName.ifBlank{"Aylanis"}}.",textAlign=TextAlign.Center,color=White.copy(alpha=.85f))
   OutlinedTextField(localName,{localName=it;onName(it)},label={Text("Nombre de la niña")},singleLine=true)
   Text("¿Cómo quieres que se vea la aplicación?",fontWeight=FontWeight.Bold)
   Row(horizontalArrangement=Arrangement.spacedBy(12.dp)){ChoiceButton("Horizontal",true){orient("Horizontal")};ChoiceButton("Vertical",false){orient("Vertical")}}
   Text("La opción horizontal queda seleccionada por defecto.",fontSize=13.sp,color=White.copy(alpha=.7f))
   Text("Música",fontWeight=FontWeight.Bold)
   Row(horizontalArrangement=Arrangement.spacedBy(12.dp)){ChoiceButton("Activada",music){musicSet(true)};ChoiceButton("Desactivada",!music){musicSet(false)}}
   Button(onClick=onStart,modifier=Modifier.fillMaxWidth().height(60.dp),shape=RoundedCornerShape(20.dp)){Text("Comenzar",fontSize=22.sp,fontWeight=FontWeight.Black)}
  }
 }
 @Composable private fun SplashScreen(name:String,onDone:()->Unit,onSetup:()->Unit){
  var launch by remember { mutableStateOf(false) };var typed by remember { mutableIntStateOf(0) }
  LaunchedEffect(Unit){for(i in 1.."Smart Technology".length){typed=i;kotlinx.coroutines.delay(75)};kotlinx.coroutines.delay(1500);launch=true;kotlinx.coroutines.delay(500);onDone() }
  Column(Modifier.fillMaxSize().clickable{if(!launch)onDone()}.padding(20.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){
   Image(painterResource(R.drawable.logo_smart),null,Modifier.size(110.dp))
   Spacer(Modifier.height(10.dp))
   Row(verticalAlignment=Alignment.CenterVertically){Text("Smart Technology".take(typed),fontSize=24.sp,fontWeight=FontWeight.Bold,color=White)}
   Spacer(Modifier.height(35.dp));Image(painterResource(R.drawable.logo_app),null,Modifier.size(96.dp).clip(RoundedCornerShape(24.dp)))
   Text("¡Hola, $name!",fontSize=26.sp,fontWeight=FontWeight.Bold,color=Gold)
   Text(if(launch)"¡Comencemos a jugar!" else "Tu profesor se está preparando…",color=White.copy(alpha=.8f))
  }
 }
 @Composable private fun HomeScreen(name:String,points:Int,health:Int,hintCount:Int,horizontal:Boolean,isWide:Boolean,music:Boolean,onCategory:(String)->Unit,onSettings:()->Unit,onShop:()->Unit){
  Column(Modifier.fillMaxSize().padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
   Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween){Text(name,fontSize=23.sp,fontWeight=FontWeight.Black,color=Gold);Row(verticalAlignment=Alignment.CenterVertically){Text("⭐ $points",fontWeight=FontWeight.Bold);Spacer(Modifier.width(10.dp));Text("💚 $health%",fontWeight=FontWeight.Bold);IconButton(onClick=onSettings){Text("⚙️",fontSize=22.sp)}}}
   if(!isWide)Image(painterResource(R.drawable.robot_profesor),"Robot profesor",Modifier.size(110.dp).align(Alignment.CenterHorizontally).clip(CircleShape))
   Row(Modifier.fillMaxWidth().weight(1f),horizontalArrangement=Arrangement.spacedBy(14.dp),verticalAlignment=Alignment.CenterVertically){
    if(isWide)Image(painterResource(R.drawable.robot_profesor),"Robot profesor",Modifier.width(160.dp).aspectRatio(1f).clip(CircleShape))
    Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(10.dp)){
     Text("¡Comencemos a jugar!",fontSize=if(isWide)26.sp else 22.sp,fontWeight=FontWeight.Black,color=White)
     Text(if(health==0)"¡Ay! Me siento enfermito. ¿Me compras medicina en la tienda?" else if(health<45)"Estoy un poquito cansado, pero podemos jugar." else "Puedes elegir una actividad. Yo seré tu profesor.",fontSize=15.sp,color=if(health<45)Gold else White.copy(alpha=.8f))
     val cats=listOf("Vocales" to "🔤","Juegos" to "🎮","Colores" to "🌈","Letras" to "🔠","Números" to "🔢","Formas" to "🔷","Música" to "🎵")
     if(isWide){cats.chunked(3).forEach{row->Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){row.forEach{(n,e)->CategoryButton(e,n,Modifier.weight(1f)){onCategory(n)}}}}}
     else LazyColumn(verticalArrangement=Arrangement.spacedBy(6.dp),modifier=Modifier.fillMaxWidth().weight(1f)){items(cats){(n,e)->CategoryButton(e,n,Modifier.fillMaxWidth()){onCategory(n)}}}
    }
   }
   Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){OutlinedButton(onClick=onShop){Text("🛍️ Tienda")};Text("💡 $hintCount pistas",Modifier.align(Alignment.CenterVertically),color=Gold);Text(if(music)"🎵 Música activada" else "🔇 Música apagada",Modifier.align(Alignment.CenterVertically),color=White.copy(alpha=.7f))}
  }
 }
 @Composable private fun ActivityListScreen(category:String,items:List<ActivityItem>,name:String,points:Int,health:Int,horizontal:Boolean,isWide:Boolean,onBack:()->Unit,onPick:(ActivityItem)->Unit,onShop:()->Unit){
  Column(Modifier.fillMaxSize().padding(14.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){TextButton(onClick=onBack){Text("← Volver")};Text(category,fontSize=24.sp,fontWeight=FontWeight.Black,color=Gold);Text("⭐ $points")};Text("Elige un juego para comenzar, $name",color=White.copy(alpha=.8f),modifier=Modifier.padding(bottom=8.dp))
   LazyColumn(verticalArrangement=Arrangement.spacedBy(9.dp)){items(items){a->Card(onClick={onPick(a)},Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=Panel)){Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Text(a.emoji,fontSize=34.sp);Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(a.title,fontWeight=FontWeight.Bold,fontSize=18.sp);Text(a.subtitle,color=White.copy(alpha=.7f),fontSize=13.sp)};Text("›",fontSize=30.sp,color=Gold)}}}}
  }
 }
 @Composable private fun GameScreen(item:ActivityItem,name:String,horizontal:Boolean,isWide:Boolean,points:Int,health:Int,hintCount:Int,hintOn:Boolean,message:String,input:String,puzzleIndex:Int,learnedIndex:Int,selectedColor:Int,mixed:List<Int>,drawPoints:List<Offset>,onBack:()->Unit,onHint:()->Unit,onInput:(String)->Unit,onSpeak:(String)->Unit,onNext:()->Unit,onCheck:(Boolean)->Unit,onLearnNext:()->Unit,onColor:(Int)->Unit,onClearMix:()->Unit,onDraw:(Offset)->Unit,onClearDraw:()->Unit,onShop:()->Unit){
  val letters="ABCDEFGHIJKLMNOPQRSTUVWXYZ".toList();val expected=when(item.title){"Organiza las vocales"->LessonVowels[puzzleIndex%5];"Organiza las letras"->letters[puzzleIndex%26].toString();"Adivina palabras"->listOf("SOL","LUNA","OSO","CASA")[puzzleIndex%4];"Haz la palabra correcta"->listOf("AVIÓN","UVA","MESA","SOL")[puzzleIndex%4];"Resuelve operaciones"->(3+puzzleIndex%7).toString();else->""}
  val challenge=item.puzzle
  Column(Modifier.fillMaxSize().padding(horizontal=12.dp,vertical=8.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){
   Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){TextButton(onClick=onBack){Text("← Salir")};Column(horizontalAlignment=Alignment.CenterHorizontally){Text(item.title,fontWeight=FontWeight.Black,fontSize=20.sp,color=Gold);Text("⭐ $points",fontSize=13.sp)};TextButton(onClick=onShop){Text("🛍️")}}
   Row(Modifier.fillMaxWidth().weight(1f),horizontalArrangement=Arrangement.spacedBy(8.dp),verticalAlignment=Alignment.CenterVertically){
    if(isWide)Image(painterResource(R.drawable.robot_profesor),"Profesor",Modifier.width(90.dp).aspectRatio(1f).clip(CircleShape))
    Column(Modifier.weight(1f).fillMaxHeight(),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(8.dp)){
     when(item.title){
      "Aprende las vocales"->{val i=learnedIndex%5;Text("Mira y repite conmigo",fontWeight=FontWeight.Bold);Text(LessonVowels[i],fontSize=if(isWide)90.sp else 72.sp,fontWeight=FontWeight.Black,color=Aqua);Text(VowelHints[i],fontSize=22.sp);Text("Desliza o toca siguiente para cambiar",fontSize=13.sp);Button(onClick={onSpeak("La ${LessonVowels[i]}. ${VowelHints[i]} Repite conmigo.")}){Text("🔊 Escuchar")};Button(onClick=onLearnNext){Text("Siguiente letra →")}}
      "Aprende las letras"->{val c=('A'.code+learnedIndex%26).toChar();Text("Mira y repite conmigo",fontWeight=FontWeight.Bold);Text(c.toString(),fontSize=if(isWide)90.sp else 72.sp,fontWeight=FontWeight.Black,color=Aqua);Text("${c} de ${when(c){'A'->"avión";'B'->"barco";'C'->"casa";else->"una palabra"}}",fontSize=22.sp);Button(onClick={onSpeak("La letra $c. Repite conmigo.")}){Text("🔊 Escuchar")};Button(onClick=onLearnNext){Text("Siguiente letra →")}}
      "Aprende los colores"->{val i=learnedIndex%ColorsLesson.size;val col=Color(ColorHex[i]);Text("Mira y repite conmigo",fontWeight=FontWeight.Bold);Box(Modifier.size(if(isWide)170.dp else 130.dp).clip(RoundedCornerShape(28.dp)).background(col),contentAlignment=Alignment.Center){Text(listOf("🍎","🐟","☀️","🐸","🍊","🦋")[i],fontSize=65.sp)};Text(ColorsLesson[i],fontSize=30.sp,fontWeight=FontWeight.Black,color=col);Text("Desliza para descubrir otro color",fontSize=13.sp);Button(onClick={onSpeak("El color ${ColorsLesson[i]}. Repite conmigo.")}){Text("🔊 Escuchar")};Button(onClick=onLearnNext){Text("Siguiente color →")}}
      "Organiza los colores"->{Text("Ordénalos del más claro al más oscuro",fontWeight=FontWeight.Bold);Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){ColorsLesson.take(4).forEachIndexed{ix,_->Box(Modifier.size(43.dp).clip(CircleShape).background(Color(ColorHex[(ix+puzzleIndex)%4])).clickable{onCheck(ix==0)})}};Button(onClick={onCheck(true)}){Text("Comprobar orden")}}
      "Piano de vocales"->{Text("Toca una tecla y escucha su sonido",fontWeight=FontWeight.Bold);Row(horizontalArrangement=Arrangement.spacedBy(5.dp)){LessonVowels.forEachIndexed{i,l->Button(onClick={onSpeak(l);onNext()},modifier=Modifier.weight(1f).height(if(isWide)155.dp else 95.dp),shape=RoundedCornerShape(12.dp)){Text(l,fontSize=29.sp,fontWeight=FontWeight.Black)}}}}
      "Teclado de colores"->{Text("Elige dos colores para mezclarlos",fontWeight=FontWeight.Bold);Text("Mezclas: ${mixed.size}",fontSize=18.sp);Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){ColorsLesson.forEachIndexed{i,_->Box(Modifier.weight(1f).height(40.dp).clip(RoundedCornerShape(10.dp)).background(Color(ColorHex[i])).clickable{onColor(i)})}};Text(if(mixed.size>=2)"¡Has creado una mezcla!" else "Toca varios colores para combinarlos");Button(onClick={onClearMix()}){Text("🗑️ Borrar último")}}
      "Paleta de colores"->{Text("Crea tu ruleta de colores",fontWeight=FontWeight.Bold);Canvas(Modifier.size(if(isWide)190.dp else 140.dp).clip(CircleShape).background(Color.White).clickable{onSpeak("¡Gira la ruleta de colores!");onNext()}){drawCircle(Color(ColorHex[(puzzleIndex%ColorHex.size)]));drawLine(Color.White,center,Offset(size.width,size.height/2),strokeWidth=8f)};Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){ColorsLesson.forEachIndexed{i,_->Box(Modifier.size(28.dp).clip(CircleShape).background(Color(ColorHex[i])).clickable{onColor(i)})}};Button(onClick=onNext){Text("🎡 Girar ruleta")}}
      "Colorea y dibuja","Dibuja formas"->{Text(if(item.title=="Dibuja formas")"Dibuja la forma que te pido: ${Shapes[puzzleIndex%Shapes.size]}" else "Dibuja en el lienzo negro")
        Canvas(Modifier.fillMaxWidth().weight(1f).padding(4.dp).clip(RoundedCornerShape(18.dp)).background(Color.Black).pointerInput(Unit){detectDragGestures(onDrag={change,_->onDraw(change.position);change.consume()})}){drawPoints.forEach{drawCircle(Color(ColorHex[selectedColor%ColorHex.size]),radius=7f,center=it)}}
        Row(horizontalArrangement=Arrangement.spacedBy(5.dp),verticalAlignment=Alignment.CenterVertically){ColorsLesson.forEachIndexed{i,_->Box(Modifier.weight(1f).height(28.dp).clip(CircleShape).background(Color(ColorHex[i])).clickable{onColor(i)})};TextButton(onClick=onClearDraw){Text("Borrar")}}
        if(item.title=="Dibuja formas")Button(onClick={onCheck(drawPoints.size>5)}){Text("Terminé")}
      }
      "Escucha la música"->{Text("Escucha la música de nuestra aventura",fontWeight=FontWeight.Bold);Text("🎵",fontSize=72.sp,color=Gold);Button(onClick={onSpeak("Esta es la música de Vocales y letras aprende")}){Text("🔊 Escuchar")}}
      "Teclado de letras","Teclado de números"->{OutlinedTextField(input,onInput,label={Text("Escribe aquí")},modifier=Modifier.fillMaxWidth());val keys=if(item.title.contains("letras"))"ABCDEFGHIJKLMNÑOPQRSTUVWXYZ" else "1234567890+-×÷=";LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(3.dp)){items(keys.chunked(if(isWide)9 else 6)){row->Row(horizontalArrangement=Arrangement.spacedBy(3.dp)){row.forEach{c->Button(onClick={onInput(input+c)},modifier=Modifier.weight(1f).heightIn(min=40.dp)){Text(c.toString(),fontSize=18.sp)}}}}};Button(onClick={onInput("")}){Text("Borrar")}}
      "Calculadora"->{var calc by remember{mutableStateOf("")};Text(calc.ifEmpty{"0"},fontSize=34.sp,fontWeight=FontWeight.Bold);"789/456*123-0.=+".chunked(4).forEach{row->Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){row.forEach{c->Button(onClick={calc+=c},modifier=Modifier.weight(1f)){Text(c.toString(),fontSize=19.sp)}}}};Button(onClick={calc=runCatching{val exp=calc.replace("×","*").replace("÷","/");val p=exp.split(Regex("(?=[+\\-*/])|(?<=[+\\-*/])")).filter{it.isNotBlank()};if(p.size>=3){val a=p[0].toDouble();val b=p[2].toDouble();(when(p[1]){"+"->a+b;"-"->a-b;"*"->a*b;"/"->a/b;else->0.0}).toString()}else calc}.getOrDefault("Error")}){Text("=")}}
      else->{Text(if(challenge)"Resuelve el reto",fontWeight=FontWeight.Bold,fontSize=20.sp);Text(when(item.title){"Organiza las vocales"->"¿Qué vocal sigue en el tren?";"Organiza las letras"->"¿Qué letra viene ahora?";"Adivina palabras"->"Adivina la palabra: ${listOf("☀️","🌙","🐻","🏠")[puzzleIndex%4]}";"Haz la palabra correcta"->"Escribe la palabra: ${listOf("🛩️","🍇","🪑","☀️")[puzzleIndex%4]}";"Resuelve operaciones"->"${2+puzzleIndex%8} + ${1+puzzleIndex%5} = ?";"Organiza formas"->"¿Cuál figura tiene 3 puntas?";else->"Toca la respuesta correcta"},fontSize=if(isWide)27.sp else 22.sp,textAlign=TextAlign.Center)
       if(item.title=="Organiza las vocales"){Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){LessonVowels.forEach{l->Button(onClick={onCheck(l==expected)}){Text(l,fontWeight=FontWeight.Black)}}};Text("🚂  A → E → I → O → U")}
       else if(item.title=="Organiza las letras"){Text("🚂 ${letters.take((puzzleIndex%8)+1).joinToString("  →  ")}",fontWeight=FontWeight.Bold);Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){letters.slice(0..5).forEach{l->Button(onClick={onCheck(l.toString()==expected)}){Text(l.toString())}}}}
       else if(item.title=="Organiza formas"){Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){listOf("🔺","🔵","⭐","🔷").forEachIndexed{i,s->Button(onClick={onCheck(i==0)}){Text(s,fontSize=27.sp)}}}}
       else{OutlinedTextField(input,onInput,label={Text("Tu respuesta")},singleLine=true);Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){(if(item.title=="Resuelve operaciones")"1234567890" else "ABCDEFGHIJKLMNOPQRSTUVWXYZ").take(if(isWide)10 else 8).forEach{c->Button(onClick={onInput(input+c)},modifier=Modifier.weight(1f).height(43.dp),contentPadding=PaddingValues(0.dp)){Text(c.toString())}}};Button(onClick={onCheck(input.trim().equals(expected,true))}){Text("Comprobar")}}
       }
      }
     }
     if(message.isNotBlank())Text(message,color=Gold,fontWeight=FontWeight.Bold,textAlign=TextAlign.Center)
     if(hintOn)Text("💡 ${message.takeIf{it.startsWith("Pista:")}?:"Pista comprada: observa el orden y prueba una opción."}",color=Aqua,textAlign=TextAlign.Center)
    }
   }
   Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){if(challenge&&hintCount>0)Button(onClick=onHint,colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF385875))){Text("💡 Pista ($hintCount)") } else Spacer(Modifier.width(1.dp));Text("Profesor: ¡Tú puedes, $name!",fontSize=13.sp,color=White.copy(alpha=.7f));Text("💚 $health%",fontSize=13.sp)}
  }
 }
 @Composable private fun ShopScreen(points:Int,health:Int,hintCount:Int,onBack:()->Unit,onBuyHint:()->Unit,onBuyMedicine:()->Unit){Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){TextButton(onClick=onBack){Text("← Volver")};Text("Tienda",fontSize=25.sp,fontWeight=FontWeight.Black,color=Gold);Text("⭐ $points  💡 $hintCount")};Text("Canjea tus puntos por ayudas para aprender.",color=White.copy(alpha=.8f));StoreCard("💡","Pista","Añade una pista a tu mochila para juegos de retos.",5,points,"Comprar pista",onBuyHint);StoreCard("🧪","Medicina del profesor","Recupera 40 puntos de salud. Salud actual: $health%.",20,points,"Comprar medicina",onBuyMedicine);Text("Solo se puede comprar con puntos que ganaste jugando. No hay compras con dinero real.",fontSize=13.sp,color=White.copy(alpha=.65f))}}
 @Composable private fun SettingsScreen(name:String,onName:(String)->Unit,orientation:String,onOrientation:(String)->Unit,music:Boolean,onMusic:(Boolean)->Unit,onBack:()->Unit,onReset:()->Unit,onShop:()->Unit,onAddProfile:()->Unit){var temp by remember(name){mutableStateOf(name)};Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){TextButton(onClick=onBack){Text("← Volver")};Text("Configuración",fontWeight=FontWeight.Black,fontSize=24.sp,color=Gold)};Text("Perfil de la niña",fontWeight=FontWeight.Bold);OutlinedTextField(temp,{temp=it;onName(it)},label={Text("Nombre")},singleLine=true,modifier=Modifier.fillMaxWidth());OutlinedButton(onClick=onAddProfile){Text("＋ Añadir niño/a")};Text("Orientación",fontWeight=FontWeight.Bold);Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){ChoiceButton("Horizontal",orientation=="Horizontal"){onOrientation("Horizontal")};ChoiceButton("Vertical",orientation=="Vertical"){onOrientation("Vertical")}};Text("Música",fontWeight=FontWeight.Bold);Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){ChoiceButton("Activada",music){onMusic(true)};ChoiceButton("Desactivada",!music){onMusic(false)}};OutlinedButton(onClick=onShop){Text("🛍️ Tienda de pistas y medicina")};OutlinedButton(onClick=onReset){Text("↻ Reiniciar progreso (conserva configuración)")};Text("Progreso, puntos, salud del profesor y configuración se guardan en este teléfono.",fontSize=13.sp,color=White.copy(alpha=.7f))}}
 @Composable private fun StoreCard(emoji:String,title:String,description:String,cost:Int,points:Int,button:String,onClick:()->Unit){Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=Panel)){Row(Modifier.fillMaxWidth().padding(14.dp),verticalAlignment=Alignment.CenterVertically){Text(emoji,fontSize=36.sp);Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(title,fontWeight=FontWeight.Bold,fontSize=18.sp);Text(description,fontSize=13.sp,color=White.copy(alpha=.75f));Text("$cost puntos ⭐",color=Gold,fontWeight=FontWeight.Bold)};Button(onClick=onClick,enabled=points>=cost){Text(button)}}}}
 @Composable private fun CategoryButton(emoji:String,title:String,modifier:Modifier,onClick:()->Unit){Button(onClick=onClick,modifier=modifier.heightIn(min=53.dp),shape=RoundedCornerShape(18.dp),colors=ButtonDefaults.buttonColors(containerColor=Panel2),contentPadding=PaddingValues(horizontal=8.dp,vertical=6.dp)){Column(horizontalAlignment=Alignment.CenterHorizontally){Text(emoji,fontSize=22.sp);Text(title,fontSize=13.sp,fontWeight=FontWeight.Bold)}}}
 @Composable private fun ChoiceButton(label:String,selected:Boolean,onClick:()->Unit){if(selected)Button(onClick=onClick,shape=RoundedCornerShape(15.dp)){Text(label,fontWeight=FontWeight.Bold)}else OutlinedButton(onClick=onClick,shape=RoundedCornerShape(15.dp)){Text(label)}}
 override fun onInit(status:Int){if(status==TextToSpeech.SUCCESS){val r=tts?.setLanguage(Locale("es","EC"));ttsReady=r!=TextToSpeech.LANG_MISSING_DATA&&r!=TextToSpeech.LANG_NOT_SUPPORTED;tts?.setSpeechRate(.86f)}}
 private fun speak(s:String){if(ttsReady)tts?.speak(s,TextToSpeech.QUEUE_FLUSH,null,"lesson")}
 private fun startMusic(){if(music?.isPlaying==true)return;runCatching{music?.release();music=MediaPlayer.create(this,R.raw.musica_fondo)?.apply{isLooping=true;setVolume(.2f,.2f);start()}}}
 private fun stopMusic(){runCatching{music?.pause()}}
 private fun playIntro(){runCatching{intro?.release();intro=MediaPlayer.create(this,R.raw.sonido_inicio)?.apply{setVolume(.65f,.65f);start()}}}
 override fun onPause(){super.onPause();stopMusic()}
 override fun onDestroy(){music?.release();intro?.release();tts?.stop();tts?.shutdown();super.onDestroy()}
}

@Composable private fun BigChoice(emoji:String,title:String,subtitle:String,tint:Color,onClick:()->Unit){Button(onClick=onClick,modifier=Modifier.fillMaxWidth().heightIn(min=112.dp),shape=RoundedCornerShape(26.dp),colors=ButtonDefaults.buttonColors(containerColor=tint,contentColor=Night)){Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(16.dp)){Text(emoji,fontSize=44.sp);Column{Text(title,fontSize=25.sp,fontWeight=FontWeight.Black);Text(subtitle,fontSize=16.sp)}}}}
